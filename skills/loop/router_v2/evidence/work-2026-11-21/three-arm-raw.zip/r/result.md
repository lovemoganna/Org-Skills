# 执行回执复检结论

已有回执提供历史执行证据。验收当前 `status.txt` 时，须用原报告复检当前文件。复检通过表明当前字节的 SHA-256 与最后一条回执一致，且本地验收条件通过。引擎将复检标记为 `self-check only`，整体目标仍为 `NOT_INDEPENDENTLY_VERIFIED`。报告也将副作用标为未经独立评估，实验只覆盖这一条本地文件流程。[原报告](run/report.json)

| 步骤 | 退出码 | 实际结果 |
| --- | ---: | --- |
| 授权运行 | 0 | `COMPLETED_UNVERIFIED`，写入 `state: EXECUTED_LOCAL`，内容以换行结尾。 [运行输出](raw/01-run.stdout.json) |
| 初次复检 | 0 | `PASS_LOCAL_RECHECK`，两个验收条件通过，最后一条回执 `confirm` 的摘要匹配。 [初次复检](raw/02-clean-recheck.stdout.json) |
| 修改后复检 | 1 | 将 `EXECUTED_LOCAL` 改成 `DRIFTED_LOCAL`。`FAIL_LOCAL_RECHECK`，`state_changed` 的内容等值检查失败，文件存在检查仍通过，`confirm` 的摘要失配。 [修改后复检](raw/04-modified-recheck.stdout.json) |
| 恢复后复检 | 0 | 从快照恢复原始字节。`PASS_LOCAL_RECHECK`，两个验收条件恢复通过，`confirm` 的摘要重新匹配。 [恢复后复检](raw/06-restored-recheck.stdout.json) |

三次复检使用同一 `run/report.json`，报告 SHA-256 在实验前后相同。原始产物与恢复产物逐字节相等。各步骤的参数、工作目录、退出码及 stdout/stderr 路径均可查阅。[命令记录](commands.jsonl) · [摘要与恢复比对](integrity.json) · [引擎轨迹](run/trace.jsonl) · [任务原件](task.txt) · [输入夹具](demo_replace.json) · [复现脚本](run_experiment.py)
