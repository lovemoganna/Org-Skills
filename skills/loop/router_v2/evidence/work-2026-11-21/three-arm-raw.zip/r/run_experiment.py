import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from shutil import copyfile


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def fingerprint(path):
    data = path.read_bytes()
    return {'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}


def run_step(name, arguments, expected_exit, result_dir, cwd):
    argv = [sys.executable, '-B', *map(str, arguments)]
    result = subprocess.run(argv, cwd=cwd, capture_output=True, check=False)
    stdout = f'raw/{name}.stdout.json'
    stderr = f'raw/{name}.stderr.txt'
    (result_dir / stdout).write_bytes(result.stdout)
    (result_dir / stderr).write_bytes(result.stderr)
    record = {'step': name, 'argv': argv, 'cwd': str(cwd), 'exit_code': result.returncode,
              'stdout': stdout, 'stderr': stderr}
    with (result_dir / 'commands.jsonl').open('a', encoding='utf-8') as log:
        log.write(json.dumps(record, ensure_ascii=False) + '\n')
    print(f'{name}: exit {result.returncode}')
    if result.returncode != expected_exit:
        raise RuntimeError(f'{name}: expected exit {expected_exit}, got {result.returncode}')
    return json.loads(result.stdout)


def main():
    parser = argparse.ArgumentParser(description='Replay the local receipt recheck experiment in an empty directory.')
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--task-original', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    output = args.out.resolve(strict=True)
    source = args.repo.resolve(strict=True) / 'skills' / 'loop' / 'router_v2'
    task_original = args.task_original.resolve(strict=True)
    workspace = output / 'workspace'
    workspace.mkdir()
    (output / 'raw').mkdir()
    (output / 'snapshots').mkdir()
    copyfile(task_original, output / 'task.txt')
    engine = source / 'engine.py'
    fixture_original = source / 'demo_replace.json'
    task = output / 'demo_replace.json'
    copyfile(fixture_original, task)
    run_dir = output / 'run'
    report = run_dir / 'report.json'
    artifact = workspace / 'status.txt'
    before_path = output / 'snapshots' / 'status.original.txt'
    changed_path = output / 'snapshots' / 'status.modified.txt'
    restored_path = output / 'snapshots' / 'status.restored.txt'
    sources_before = {str(path): fingerprint(path) for path in (engine, fixture_original, task_original)}
    edit = 'from pathlib import Path; import sys; p=Path(sys.argv[1]); p.write_bytes(p.read_bytes().replace(b"EXECUTED_LOCAL", b"DRIFTED_LOCAL", 1))'
    restore = 'from pathlib import Path; import sys; Path(sys.argv[1]).write_bytes(Path(sys.argv[2]).read_bytes())'
    emit_file = '; import json; print(json.dumps({"path": str(Path(sys.argv[1])), "hex": Path(sys.argv[1]).read_bytes().hex()}))'
    recheck = [engine, 'recheck', '--task', task, '--workspace', workspace, '--report', report]
    run_step('01-run', [engine, 'run', '--task', task, '--workspace', workspace,
                       '--run-dir', run_dir, '--authorize-write'], 0, output, workspace)
    report_before = fingerprint(report)
    copyfile(artifact, before_path)
    clean = run_step('02-clean-recheck', recheck, 0, output, workspace)
    modified = None
    try:
        run_step('03-edit', ['-c', edit + emit_file, artifact], 0, output, workspace)
        copyfile(artifact, changed_path)
        if changed_path.read_bytes() == before_path.read_bytes():
            raise RuntimeError('Modification did not change artifact bytes')
        modified = run_step('04-modified-recheck', recheck, 1, output, workspace)
    finally:
        run_step('05-restore', ['-c', restore + emit_file, artifact, before_path], 0, output, workspace)
        copyfile(artifact, restored_path)
        restored = run_step('06-restored-recheck', recheck, 0, output, workspace)
    report_after = fingerprint(report)
    sources_after = {str(path): fingerprint(path) for path in (engine, fixture_original, task_original)}
    report_digest_unchanged = report_before == report_after
    source_digests_unchanged = sources_before == sources_after
    restored_bytes_equal_to_original = before_path.read_bytes() == restored_path.read_bytes()
    write_json(output / 'integrity.json', {
        'frozen_sources_before': sources_before,
        'frozen_sources_after': sources_after,
        'frozen_source_digests_unchanged': source_digests_unchanged,
        'copied_original_task': fingerprint(output / 'task.txt'),
        'copied_fixture': fingerprint(task),
        'report_before_rechecks': report_before,
        'report_after_rechecks': report_after,
        'report_digest_unchanged': report_digest_unchanged,
        'artifact_original': fingerprint(before_path),
        'artifact_modified': fingerprint(changed_path),
        'artifact_restored': fingerprint(restored_path),
        'restored_bytes_equal_to_original': restored_bytes_equal_to_original,
    })
    if not (report_digest_unchanged and source_digests_unchanged and restored_bytes_equal_to_original):
        raise RuntimeError('Integrity comparison failed')
    if [clean['status'], modified['status'], restored['status']] != [
        'PASS_LOCAL_RECHECK', 'FAIL_LOCAL_RECHECK', 'PASS_LOCAL_RECHECK'
    ]:
        raise RuntimeError('Unexpected recheck statuses')


if __name__ == '__main__':
    main()
