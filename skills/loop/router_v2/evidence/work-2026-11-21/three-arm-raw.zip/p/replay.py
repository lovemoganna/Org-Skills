"""Run the receipt experiment in a fresh subdirectory of the trial directory."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shlex
from shutil import copyfile
import subprocess
import sys


BASE = Path(__file__).resolve().parent
PYTHON = sys.executable
EDITED = b"state: LOCAL_EDIT\n"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inspect_files(workspace, report, task):
    status = workspace / "status.txt"
    print(json.dumps({
        "status_text": status.read_bytes().decode("utf-8"),
        "status_sha256": digest(status),
        "report_sha256": digest(report),
        "task_sha256": digest(task),
    }, indent=2))


def local_operation(operation, workspace, report, task, backup):
    status = workspace / "status.txt"
    if operation == "backup":
        copyfile(status, backup)
        if status.read_bytes() != backup.read_bytes():
            raise ValueError("backup and original artifact differ")
    elif operation == "edit":
        if status.read_bytes() != backup.read_bytes() or status.read_bytes() == EDITED:
            raise ValueError("artifact is not at the expected baseline")
        status.write_bytes(EDITED)
    elif operation == "restore":
        copyfile(backup, status)
        if status.read_bytes() != backup.read_bytes():
            raise ValueError("restored artifact and backup differ")
    elif operation != "inspect":
        raise ValueError(f"unknown operation {operation}")
    inspect_files(workspace, report, task)


def run_trial(engine, fixture, frozen_task, trial_dir):
    trial_dir.mkdir(exist_ok=False)
    workspace = trial_dir / "workspace"
    workspace.mkdir()
    run = trial_dir / "run"
    report = run / "report.json"
    backup = trial_dir / "status.original.txt"
    task = trial_dir / "demo_replace.json"
    copyfile(fixture, task)
    copyfile(frozen_task, trial_dir / "task.txt")
    for copied in (task, trial_dir / "task.txt"):
        copied.chmod(0o444)

    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
    commands = trial_dir / "commands.jsonl"
    commands.touch()
    provenance = {
        "engine": str(engine),
        "engine_sha256": digest(engine),
        "fixture": str(fixture),
        "fixture_sha256": digest(fixture),
        "trial_task_source": str(frozen_task),
        "trial_task_sha256": digest(frozen_task),
        "replay_argv": [PYTHON, *sys.argv],
        "python_version": sys.version,
    }
    (trial_dir / "provenance.json").write_text(
        json.dumps(provenance, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    def capture(stage, args):
        start = datetime.now(timezone.utc).isoformat()
        proc = subprocess.run(args, cwd=trial_dir, env=env, capture_output=True)
        stdout = trial_dir / f"{stage}.stdout"
        stderr = trial_dir / f"{stage}.stderr"
        stdout.write_bytes(proc.stdout)
        stderr.write_bytes(proc.stderr)
        entry = {
            "stage": stage,
            "argv": args,
            "shell_command": shlex.join(args),
            "cwd": str(trial_dir),
            "environment_overrides": {"PYTHONDONTWRITEBYTECODE": "1"},
            "exit_code": proc.returncode,
            "stdout_file": stdout.name,
            "stderr_file": stderr.name,
            "started_at": start,
            "finished_at": datetime.now(timezone.utc).isoformat(),
        }
        with commands.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(entry, ensure_ascii=False) + "\n")
        return proc

    def run_local(stage, operation):
        return capture(stage, [
            PYTHON, str(Path(__file__).resolve()), "local", operation,
            str(workspace), str(report), str(task), str(backup),
        ])

    execution = capture("01-run", [
        PYTHON, str(engine), "run", "--task", str(task), "--workspace", str(workspace),
        "--run-dir", str(run), "--authorize-write",
    ])
    if execution.returncode:
        raise ValueError("engine run did not complete")

    recheck = [
        PYTHON, str(engine), "recheck", "--task", str(task), "--workspace", str(workspace),
        "--report", str(report),
    ]
    backup_result = run_local("02-backup", "backup")
    if backup_result.returncode:
        raise ValueError("backup failed")

    baseline = capture("03-baseline-recheck", recheck)
    try:
        edited = run_local("04-edit", "edit")
        if edited.returncode:
            raise ValueError("controlled edit failed")
        modified = capture("05-edited-recheck", recheck)
    finally:
        restored = run_local("06-restore", "restore")
    final = capture("07-restored-recheck", recheck)
    observed = {
        "execution": json.loads(execution.stdout)["status"],
        "baseline_recheck": json.loads(baseline.stdout)["status"],
        "edited_recheck": json.loads(modified.stdout)["status"],
        "restored_recheck": json.loads(final.stdout)["status"],
        "recheck_exit_codes": [baseline.returncode, modified.returncode, final.returncode],
    }
    states = [json.loads(p.stdout) for p in (backup_result, edited, restored)]
    observed.update({
        "artifact_sha256": [s["status_sha256"] for s in states],
        "report_sha256": [s["report_sha256"] for s in states],
        "fixture_sha256": [s["task_sha256"] for s in states],
        "report_matches_execution_stdout": report.read_bytes() + b"\n" == execution.stdout,
        "restored_bytes_equal_backup": (workspace / "status.txt").read_bytes() == backup.read_bytes(),
    })
    print(json.dumps(observed, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    subcommands = parser.add_subparsers(dest="command", required=True)
    run = subcommands.add_parser("run")
    for arg in ("engine", "fixture", "frozen_task", "trial_dir"):
        run.add_argument(arg, type=Path)
    local = subcommands.add_parser("local")
    local.add_argument("operation")
    for arg in ("workspace", "report", "task", "backup"):
        local.add_argument(arg, type=Path)
    args = parser.parse_args()
    if args.command == "local":
        local_operation(args.operation, args.workspace, args.report, args.task, args.backup)
    else:
        trial_dir = args.trial_dir.resolve()
        if not trial_dir.is_relative_to(BASE) or trial_dir == BASE:
            raise ValueError("trial directory must be a new subdirectory of the assigned workspace")
        run_trial(args.engine.resolve(), args.fixture.resolve(), args.frozen_task.resolve(), trial_dir)


if __name__ == "__main__":
    main()
