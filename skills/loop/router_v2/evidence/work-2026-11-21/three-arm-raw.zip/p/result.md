# 执行回执复验

已有执行回执不能单独验收当前产物。用同一原报告执行本地 `recheck`，引擎会重新读取 `status.txt`，检查当前验收条件，并对照最终回执的 SHA-256。本次改动被拒绝，恢复原始字节后重新通过。引擎将复验标记为 `self-check only`，目标核验状态始终为 `NOT_INDEPENDENTLY_VERIFIED`。

| 阶段 | 本地结果 | 退出码 | 观察 |
|---|---|---:|---|
| 实际执行 | `COMPLETED_UNVERIFIED` | 0 | 写入、替换、确认三步完成 |
| 基线复验 | `PASS_LOCAL_RECHECK` | 0 | 内容等于 `state: EXECUTED_LOCAL\n`，两个验收条件及最终回执校验均通过 |
| 修改后复验 | `FAIL_LOCAL_RECHECK` | 1 | 内容改为 `state: LOCAL_EDIT\n`。文件存在检查通过，内容相等检查失败，最终 `confirm` 回执哈希失配 |
| 恢复后复验 | `PASS_LOCAL_RECHECK` | 0 | 从备份恢复，字节及 SHA-256 与基线一致，两个验收条件及最终回执校验再次通过 |

三次复验的命令参数、任务清单和报告相同。原报告 SHA-256 始终为 `ce685ccd778884e73b2d644132a4945b4563184c235bf75e472adb9fe302acbf`。引擎将同一文件较早的 `write` 和 `replace` 回执标为 `superseded`，以最后的 `confirm` 回执比对当前文件哈希。本次单一内容修改同时触发两项失败，结论仅覆盖此样例及其本地复验。

[任务原件](evidence/task.txt) · [原始任务清单](evidence/demo_replace.json) · [原报告](evidence/run/report.json) · [引擎事件](evidence/run/trace.jsonl) · [完整命令、退出码及标准输出/错误文件索引](evidence/commands.jsonl) · [哈希与恢复汇总](replay.stdout) · [重放命令](replay-command.json) · [重放脚本](replay.py)
