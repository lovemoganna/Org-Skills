"""Run the original local engine, recording all subprocess calls."""
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SOURCE = Path("/workspace/scratch/7b0baee69f08/repo/skills/loop/router_v2")
ORIGINAL_TASK = ROOT.parent / "inputs" / "task.txt"

HELPER = """
import hashlib
import json
from pathlib import Path
import sys

op, *args = sys.argv[1:]
if op == "copy":
    for source, destination in zip(args[::2], args[1::2], strict=True):
        Path(destination).write_bytes(Path(source).read_bytes())
elif op == "inspect":
    artifact, report, snapshot = map(Path, args)
    data = artifact.read_bytes()
    report_bytes = report.read_bytes()
    Path(snapshot).write_bytes(data)
    print(json.dumps({"artifact": str(artifact), "size_bytes": len(data),
                      "text": data.decode("utf-8"), "sha256": hashlib.sha256(data).hexdigest(),
                      "report": str(report), "report_sha256": hashlib.sha256(report_bytes).hexdigest()}))
elif op == "modify":
    artifact = Path(args[0])
    before = artifact.read_bytes()
    old, new = args[1].encode("utf-8"), args[2].encode("utf-8")
    if before.count(old) != 1:
        raise RuntimeError("expected exactly one occurrence of the original marker")
    artifact.write_bytes(before.replace(old, new, 1))
elif op == "restore":
    artifact, backup = map(Path, args)
    artifact.write_bytes(backup.read_bytes())
"""


def execute(label, *arguments):
    argv = [sys.executable, "-B", *map(str, arguments)]
    outcome = subprocess.run(argv, cwd=output, capture_output=True, encoding="utf-8")
    record = {
        "label": label,
        "cwd": str(output),
        "argv": argv,
        "command": shlex.join(argv),
        "exit_code": outcome.returncode,
        "stdout": outcome.stdout,
        "stderr": outcome.stderr,
    }
    with (output / "commands.jsonl").open("a", encoding="utf-8") as log:
        log.write(json.dumps(record, ensure_ascii=False) + "\n")
    (output / f"{label}.stdout").write_text(outcome.stdout, encoding="utf-8")
    (output / f"{label}.stderr").write_text(outcome.stderr, encoding="utf-8")
    return outcome


def require(outcome, expected=0):
    if outcome.returncode != expected:
        raise RuntimeError(f"{shlex.join(outcome.args)} exited {outcome.returncode}; expected {expected}")
    return outcome


def snapshot(phase, artifact, report):
    observed = require(execute(f"snapshot-{phase}", "-c", HELPER, "inspect",
                               artifact, report, output / f"artifact-{phase}.txt"))
    return json.loads(observed.stdout)


def verify_phases(run_result, baseline, changed, restored, snapshots):
    statuses = [json.loads(result.stdout) for result in (run_result, baseline, changed, restored)]
    expected = ["COMPLETED_UNVERIFIED", "PASS_LOCAL_RECHECK", "FAIL_LOCAL_RECHECK",
                "PASS_LOCAL_RECHECK"]
    if [value["status"] for value in statuses] != expected:
        raise RuntimeError("unexpected engine statuses")
    expected_checks = [{"state_changed": "PASS", "status_file_exists": "PASS"},
                       {"state_changed": "FAIL", "status_file_exists": "PASS"},
                       {"state_changed": "PASS", "status_file_exists": "PASS"}]
    for phase, case in zip(statuses[1:], expected_checks, strict=True):
        if {entry["id"]: entry["status"] for entry in phase["acceptance"]} != case:
            raise RuntimeError("unexpected acceptance verdict")
    for phase, expected_match in zip(statuses[1:], [True, False, True], strict=True):
        final = next(entry for entry in phase["receipt_integrity"] if not entry["superseded"])
        if final["action_id"] != "confirm" or final["last_receipt_matches_current"] is not expected_match:
            raise RuntimeError("unexpected final receipt check")
    if len({value["report_sha256"] for value in snapshots}) != 1:
        raise RuntimeError("original run report changed")
    if snapshots[0]["sha256"] != snapshots[2]["sha256"] or snapshots[0]["sha256"] == snapshots[1]["sha256"]:
        raise RuntimeError("artifact hashes do not show change and restoration")
    if json.loads(report.read_bytes()) != statuses[0]:
        raise RuntimeError("original report differs from original run stdout")


output = (ROOT / sys.argv[1]).resolve() if len(sys.argv) == 2 else ROOT
if not output.is_relative_to(ROOT) or len(sys.argv) > 2:
    raise SystemExit("usage: experiment.py [fresh-subdirectory-under-this-directory]")
output.mkdir(exist_ok=True)
if (output / "commands.jsonl").exists():
    raise SystemExit("Existing evidence present; choose a fresh subdirectory.")

engine = SOURCE / "engine.py"
fixture = output / "demo_replace.json"
workspace = output / "workspace"
run_dir = output / "original-run"
report = run_dir / "report.json"
artifact = workspace / "status.txt"
workspace.mkdir()
require(execute("preserve-inputs", "-c", HELPER, "copy", ORIGINAL_TASK, output / "task.txt",
                SOURCE / "demo_replace.json", fixture))
require(execute("provenance", "-c",
                "from pathlib import Path; import hashlib, sys; "
                "print(sys.version); "
                "[print(hashlib.sha256(Path(f).read_bytes()).hexdigest(), f) for f in sys.argv[1:]]",
                engine, SOURCE / "demo_replace.json", fixture, ORIGINAL_TASK, output / "task.txt"))
run_result = require(execute("run", engine, "run", "--task", fixture,
                             "--workspace", workspace, "--run-dir", run_dir,
                             "--authorize-write"))
recheck = (engine, "recheck", "--task", fixture, "--workspace", workspace, "--report", report)
baseline_snapshot = snapshot("baseline", artifact, report)
baseline = execute("recheck-baseline", *recheck)
try:
    require(execute("modify", "-c", HELPER, "modify", artifact, "EXECUTED_LOCAL", "CHANGED_LOCAL"))
    modified_snapshot = snapshot("modified", artifact, report)
    changed = execute("recheck-modified", *recheck)
finally:
    require(execute("restore", "-c", HELPER, "restore", artifact, output / "artifact-baseline.txt"))
    restored_snapshot = snapshot("restored", artifact, report)
    restored = execute("recheck-restored", *recheck)

for outcome, expected in ((baseline, 0), (changed, 1), (restored, 0)):
    require(outcome, expected)
verify_phases(run_result, baseline, changed, restored,
              (baseline_snapshot, modified_snapshot, restored_snapshot))
print("Verified baseline, modified and restored states. Original report SHA-256:",
      baseline_snapshot["report_sha256"])
