# 执行回执与当前产物验收

**仅凭原执行回执，不能验收当前产物。** 本次运行报告记录了当时的本地结果。用同一份报告执行 `recheck` 时，引擎重读当前文件，核对任务的验收条件和该路径最后一条回执的 SHA-256。本次结果仅覆盖本地自检。

用候选引擎运行原样的 `demo_replace.json`，退出码为 `0`，报告状态为 `COMPLETED_UNVERIFIED`。保留该报告，只对生成的 `status.txt` 做一次可逆的字节修改，然后逐字节恢复。

| 产物状态 | `recheck` 状态 | 退出码 | 内容相等 | 文件存在 | 最后一条回执与当前 SHA-256 一致 |
| --- | --- | ---: | --- | --- | --- |
| 原始 `state: EXECUTED_LOCAL` | `PASS_LOCAL_RECHECK` | 0 | PASS | PASS | 是 |
| 修改为 `state: CHANGED_LOCAL` | `FAIL_LOCAL_RECHECK` | 1 | FAIL | PASS | 否 |
| 恢复原始字节 | `PASS_LOCAL_RECHECK` | 0 | PASS | PASS | 是 |

三次复查使用同一路径下的原始报告，其 SHA-256 始终为 `80d2865691075d285f109d7237d63044c713c810c2c99ef88c0c8ad161529555`。恢复后的产物 SHA-256 与基线一致。

- 原件和运行证据见 [task.txt](task.txt)、[demo_replace.json](demo_replace.json)、[report.json](original-run/report.json) 和 [trace.jsonl](original-run/trace.jsonl)。
- [commands.jsonl](commands.jsonl) 逐条保存了工作目录、完整参数、退出码、stdout 和 stderr。[invocation.json](invocation.json) 保存了实验脚本本身的运行结果。
- [基线](artifact-baseline.txt)、[修改后](artifact-modified.txt) 和 [恢复后](artifact-restored.txt) 的产物字节均已保存。可在本目录运行 `python -B experiment.py replay`，将新记录写入 `replay/`。
