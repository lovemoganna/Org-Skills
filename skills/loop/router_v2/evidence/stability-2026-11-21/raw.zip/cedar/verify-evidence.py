from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import sys

MODE, CHECKOUT, OUTPUT = sys.argv[1:]
OUTPUT = Path(OUTPUT)
CHECKOUT = Path(CHECKOUT)
PIN = "af94fbae23326e6ac9626bf525407fcaf59f7659"
EVIDENCE = "skills/loop/router_v2/evidence/work-2026-11-21/C-replay"

def git(*args: str, data: bytes | None = None, expected: int = 0):
    command = ["git", "-C", str(CHECKOUT), *args]
    result = subprocess.run(command, input=data, capture_output=True, check=False)
    print("$", shlex.join(command))
    print(f"exit={result.returncode}")
    if result.stderr:
        print(result.stderr.decode(), end="")
    assert result.returncode == expected
    return result.stdout

def blob(data: bytes) -> str:
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()

def replay() -> None:
    raw = OUTPUT / "N-raw"
    raw.mkdir()
    originals = (
        "read-1-receipt.json", "read-2-receipt.json", "trace.jsonl",
        "read-1-report.json", "read-2-report.json", "session.json",
    )
    for name in originals:
        from_git = git("show", f"{PIN}:{EVIDENCE}/{name}")
        assert from_git == (CHECKOUT / EVIDENCE / name).read_bytes()
        (raw / name).write_bytes(from_git)
        print(f"source={EVIDENCE}/{name} bytes={len(from_git)} sha256={hashlib.sha256(from_git).hexdigest()}")
    failed = json.loads((raw / originals[0]).read_bytes())
    recovered = json.loads((raw / originals[1]).read_bytes())
    events = [json.loads(line) for line in (raw / originals[2]).read_bytes().splitlines()]
    failure_report, recovery_report, session = (
        json.loads((raw / source).read_bytes()) for source in originals[3:])
    a = failed["request"]["args"]
    b = recovered["request"]["args"]
    error_data = failed["response"]["structuredContent"]["error_data"]
    assert error_data["status"] == "404" and failed["response"]["isError"]
    assert a["repository_full_name"] == b["repository_full_name"] == "lovemoganna/Org-Skills"
    assert a["ref"] == b["ref"] and a["path"] != b["path"]
    assert failed["request"]["request_sha256"] == events[1]["request_sha256"] == events[2]["failed_request_sha256"] == failure_report["request_sha256"]
    assert failure_report["status"] == events[1]["status"] == "FAILED"
    assert failure_report["artifact_ref"] is None and events[1]["artifact_ref"] is None
    assert events[2]["event"] == "READ_RETRY_REQUESTED" and events[2]["path"] == b["path"]
    assert events[3]["attempt"] == recovered["request"]["attempt"] == 2
    assert events[3]["request_sha256"] == recovered["request"]["request_sha256"] == recovery_report["request_sha256"]
    assert recovered["response"]["isError"] is False and recovery_report["status"] == events[3]["status"] == "SUCCESS"
    assert recovery_report["artifact_ref"] == events[3]["artifact_ref"] == originals[1]
    assert session["results"]["read"]["request_sha256"] == events[3]["request_sha256"]
    print("request_1 =", a)
    print("request_2 =", b)
    print("trace =", json.dumps(events, ensure_ascii=False))
    assert b["ref"] == "06c23284dd275cf424eeecce6fd0b6faaee298e6"
    assert git("cat-file", "-t", b["ref"]).strip() == b"commit"
    git("cat-file", "-e", f"{a['ref']}:{a['path']}", expected=128)
    data = recovered["response"]["structuredContent"]
    assert data["encoding"] == "utf-8"
    from_receipt = data["content"].encode("utf-8")
    (raw / "recovered-README.md").write_bytes(from_receipt)
    receipt_sha = data["sha"]
    actual = git("hash-object", "--stdin", data=from_receipt).decode().strip()
    historical = git("show", f"{b['ref']}:{b['path']}")
    historical_sha = git("rev-parse", f"{b['ref']}:{b['path']}").decode().strip()
    assert from_receipt == historical and actual == blob(from_receipt) == historical_sha == receipt_sha
    print(f"recovered_utf8_bytes={len(from_receipt)} receipt_sha={receipt_sha} git_hash_object={actual} historical_blob={historical_sha}")
    print("PASS: 404 → explicitly requested one path correction → SUCCESS, identical blob")

def live() -> None:
    session_path = OUTPUT / "L-session"
    session_results = json.loads((OUTPUT / "L-raw-execution.json").read_bytes())
    assert session_results["final"]["status"] == "RECEIPTS_RECORDED_UNVERIFIED"
    assert len(session_results["toolCalls"]) == 3
    for name in ("pr", "workflow", "trace"):
        receipt = json.loads((session_path / f"{name}-1-receipt.json").read_bytes())
        data = receipt["response"]["structuredContent"]
        args = receipt["request"]["args"]
        print(f"tool={receipt['tool']} args={json.dumps(args)}")
        assert receipt["response"]["isError"] is False
        if name == "pr":
            assert data["number"] == args["pr_number"] == 118
            selected = {k:data[k] for k in ("number", "state", "merged", "mergeable", "draft", "base", "head", "head_sha", "updated_at", "merged_at", "url")}
            print(json.dumps(selected, ensure_ascii=False))
            assert selected["head_sha"] == PIN
        else:
            assert args["ref"] == PIN and data["encoding"] == "utf-8"
            raw_content = data["content"].encode("utf-8")
            from_git = git("show", f"{PIN}:{args['path']}")
            actual = git("hash-object", "--stdin", data=raw_content).decode().strip()
            expected = git("rev-parse", f"{PIN}:{args['path']}").decode().strip()
            assert raw_content == from_git and data["sha"] == actual == expected == blob(raw_content)
            print(f"PASS: {name}; bytes={len(raw_content)} response_blob={data['sha']} local_blob={expected} exact_bytes_equal=true")
            if name == "workflow":
                (OUTPUT / "L-workflow-returned.yml").write_bytes(raw_content)
            if name == "trace":
                (OUTPUT / "L-trace-returned.jsonl").write_bytes(raw_content)

assert git("rev-parse", "HEAD").decode().strip() == PIN
{"N": replay, "L": live}[MODE]()
