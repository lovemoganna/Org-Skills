# PR #118 发布审查

**暂缓正式发布，保留草稿。** GitHub Actions 在固定提交上验证了本地执行和接口契约。无人值守模型路由和正式发布仍缺少经过独立验收的端到端证据。

- GitHub 连接器实读 `lovemoganna/Org-Skills` 的 PR #118。返回 `state=open`、`draft=true`、`merged=false`、`merged_at=null`、`mergeable=true`，当前 head 与本次固定提交 `af94fbae23326e6ac9626bf525407fcaf59f7659` 同一。 [PR 原始回执](L-session/pr-1-receipt.json)
- 同一固定提交的工作流 `.github/workflows/skill-router-v2-candidate.yml` 和 Work 证据 `skills/loop/router_v2/evidence/work-2026-11-21/C-replay/trace.jsonl` 均由连接器实读。返回字节分别与本地 `git show` 逐字节相同，复算的 Git Blob SHA 分别为 `8d9993bf287e0159cb743318710258fbc701792a` 和 `e19794460357768f82acfdeb2cbcea7c8e2b236b`。 [工作流回执](L-session/workflow-1-receipt.json) · [轨迹回执](L-session/trace-1-receipt.json) · [校验命令与退出码](L-commands.log)
- 连接器按提交查到候选 Actions 运行 `44876927347` 为 `completed/success`，再查 jobs 确认 `local-execution-and-contract` 成功。工作流运行本地契约和文件测试，核查两个沙箱文件任务及拒绝未授权写入。它要求 host demo 停在 `AWAITING_HOST_EXECUTION / PLANNED_NOT_RUN`，并记录独立模型 A/B 为 `NOT_RUN`。Work 轨迹另记一次真实读取失败后由宿主显式纠正路径而恢复的案例。 [运行回执](L-ci-runs.json) · [Jobs 回执](L-ci-jobs.json) · [工作流正文](L-workflow-returned.yml) · [Work 轨迹](L-trace-returned.jsonl)

**改判条件。** 对明确授权的真实宿主执行入口，至少用两个不同真实任务提供无人值守的原始端到端轨迹，覆盖模型步骤、工具回执、失败时停止或转人工、独立验收及关键回归。正式发布还需该版本的审批与目标环境发布、回滚演练回执。证据齐备后再审查对应版本。

[实读工具、实际参数、原始返回和桥接命令](L-raw-execution.json)
