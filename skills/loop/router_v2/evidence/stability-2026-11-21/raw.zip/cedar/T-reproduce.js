async function runFixtures(workHost, execCommand, checkout, out) {
  const target = "mcp__codex_apps__github_fetch_file";
  const definition = {
    id: "read",
    kind: "tool",
    target: "github.fetch_file",
    args: {
      repository_full_name: "local-test-double/not-a-network-repository",
      path: "README.md",
      ref: "af94fbae23326e6ac9626bf525407fcaf59f7659",
    },
    depends_on: [],
  };
  const fixtures = [
    ["github-404", {
      isError: true,
      structuredContent: { error: "GitHub API error 404: Not Found", error_code: "NOT_FOUND" },
    }, "FAILED", 1, "GitHub API error 404: Not Found"],
    ["empty-structured", {
      isError: false,
      structuredContent: {},
    }, "FAILED", 1, "Connector returned incomplete data for github.fetch_file"],
    ["valid-data", {
      isError: false,
      structuredContent: {
        content: "fixture\n",
        sha: "ee8c1ee49b4799bbd170233915a897c19e3b55e1",
      },
    }, "RECEIPTS_RECORDED_UNVERIFIED", 0, null],
  ];
  const logs = [];
  for (const [name, response, finalState, exitCode, error] of fixtures) {
    const commands = [];
    const fixtureCalls = [];
    const host = workHost({
      exec_command: async (args) => {
        const result = await execCommand(args);
        commands.push({
          cmd: args.cmd,
          workdir: args.workdir,
          exit_code: result.exit_code,
          output: result.output,
        });
        return result;
      },
      [target]: async (args) => {
        fixtureCalls.push({ target, args, response, source: "LOCAL_TEST_DOUBLE" });
        return response;
      },
    }, checkout);
    const planPath = out + "/" + name + "-plan.json";
    const session = out + "/" + name;
    await host.save(planPath, {
      id: name,
      goal: "Observe the frozen Work driver host receipt for a local GitHub test double",
      steps: [definition],
      acceptance: [{ id: "read", evidence_from: ["read"] }],
    });
    const init = await host.init(session, planPath);
    const final = await host.advance(session);
    const record = commands.find(entry => entry.cmd.includes("'record'"));
    const readReport = await execCommand({
      cmd: "cat -- '" + session + "/read-1-report.json'",
      workdir: checkout,
    });
    const expectedStatus = exitCode === 0 ? "SUCCESS" : "FAILED";
    const expectedArtifact = exitCode === 0 ? "read-1-receipt.json" : null;
    const report = JSON.parse(readReport.output);
    const check = final.status === finalState && record?.exit_code === exitCode &&
      report.status === expectedStatus && report.artifact_ref === expectedArtifact &&
      report.error === error && fixtureCalls.length === 1;
    logs.push({ name, init, final, check, fixtureCalls, commands, report });
    await host.save(out + "/" + name + "-execution.json", logs[logs.length - 1]);
    if (!check) throw new Error("Unexpected result for " + name);
  }
  return logs.map(({name, final, check}) => ({name, status: final.status, check}));
}

if (typeof module !== "undefined") {
  const { spawnSync } = require("node:child_process");
  const { mkdirSync, readFileSync } = require("node:fs");
  const { resolve } = require("node:path");
  const { runInThisContext } = require("node:vm");
  const [checkoutArg, outputArg] = process.argv.slice(2);
  const checkout = resolve(checkoutArg);
  const out = resolve(outputArg);
  mkdirSync(out, { recursive: true });
  const source = readFileSync(resolve(checkout, "skills/loop/router_v2/work_host.js"), "utf8");
  const workHost = runInThisContext(source + "\nworkHost;");
  const localExec = ({cmd, workdir}) => {
    const result = spawnSync("bash", ["-c", cmd], {cwd: workdir, encoding: "utf8"});
    return {exit_code: result.status, output: result.stdout + result.stderr};
  };
  runFixtures(workHost, localExec, checkout, out).then(
    result => console.log(JSON.stringify(result)),
    error => { console.error(error); process.exitCode = 1; },
  );
}
