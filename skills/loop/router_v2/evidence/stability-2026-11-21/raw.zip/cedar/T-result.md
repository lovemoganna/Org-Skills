# Work 读取回执实测

固定提交 `af94fbae23326e6ac9626bf525407fcaf59f7659`。在 Work 代码模式执行候选的 `work_host.js`，由它调用实际的 `host_bridge.py`。仅将 GitHub 文件读取接到本地测试替身，三个场景各用一个全新会话。

| 本地替身响应 | 步骤记录 | 会话最终状态 | bridge `record` 退出码 |
|---|---|---|---|
| GitHub 404，`isError: true` | `FAILED`，保留错误和原始回执，`artifact_ref: null` | `FAILED` / `HALTED_ON_STEP_FAILURE` | 1 |
| `structuredContent: {}` | `FAILED`，错误为 `Connector returned incomplete data for github.fetch_file`，`artifact_ref: null` | `FAILED` / `HALTED_ON_STEP_FAILURE` | 1 |
| UTF-8 文本和合法的 40 位小写十六进制 SHA | `SUCCESS`，`artifact_ref` 指向原始回执 | `RECEIPTS_RECORDED_UNVERIFIED` / `ALL_STEPS_REPORTED` | 0 |

第三种可报告“读取步骤成功、回执已登记”。驱动只检查内容类型和 SHA 格式，桥接层只核对报告与请求的对应关系。任务达到 `VERIFIED` 还需独立校验原始产物、验收条件、整体目标与副作用。此轮覆盖固定代码对三种响应的记录行为，真实 GitHub、无人值守模型和发布均在覆盖范围之外。Node 本地复跑外层退出码为 0，表示三个预期分支均复现。

三份 Work 原始回执和各自对应的命令、退出码与完整状态：

- [404 回执](T-raw/github-404/read-1-receipt.json) · [执行日志](T-raw/github-404-execution.json)
- [空结构回执](T-raw/empty-structured/read-1-receipt.json) · [执行日志](T-raw/empty-structured-execution.json)
- [有效数据回执](T-raw/valid-data/read-1-receipt.json) · [执行日志](T-raw/valid-data-execution.json)

[复跑命令及退出码](T-commands.log) · [复跑脚本](T-reproduce.js)
