import hashlib
import json
from pathlib import Path
import subprocess
import sys

checkout, raw_path = map(Path, sys.argv[1:])
commit = "af94fbae23326e6ac9626bf525407fcaf59f7659"
rows = {row["name"]: row for row in json.loads(raw_path.read_bytes())}


def returned(name):
    settlement = rows[name]["settlement"]
    assert settlement["status"] == "fulfilled" and not settlement["value"]["isError"]
    return settlement["value"]["structuredContent"]


def git(*argv, stdin=None):
    completed = subprocess.run(["git", *argv], cwd=checkout, input=stdin, capture_output=True)
    stdout = completed.stdout.decode()
    data = {"argv": ["git", *argv], "cwd": str(checkout), "exit_code": completed.returncode,
            "stdout": stdout, "stderr": completed.stderr.decode()}
    print(json.dumps(data, ensure_ascii=False))
    assert completed.returncode == 0
    return completed.stdout


assert git("rev-parse", "HEAD").decode().strip() == commit
pr = returned("pr-118")
assert pr["number"] == 118 and pr["head_sha"] == commit
print(json.dumps({key: pr[key] for key in
                  ("url", "number", "state", "draft", "merged", "base", "head", "head_sha")}))
for name in ("workflow", "C-replay-trace"):
    args = rows[name]["args"]
    assert args["ref"] == commit
    path = args["path"]
    result = returned(name)
    assert result["encoding"] == "utf-8"
    raw = result["content"].encode("utf-8")
    header = f"blob {len(raw)}".encode("ascii") + bytes([0])
    computed = hashlib.sha1(header + raw).hexdigest()
    stdin_sha = git("hash-object", "--stdin", stdin=raw).decode().strip()
    pinned = git("rev-parse", f"{commit}:{path}").decode().strip()
    assert result["sha"] == computed == stdin_sha == pinned
    assert git("cat-file", "blob", pinned) == raw
    print(json.dumps({"name": name, "path": path, "bytes": len(raw), "declared_sha": result["sha"],
                      "computed_sha": computed, "local_object_sha": pinned, "identical_bytes": True}))

workflow = returned("workflow")["content"]
for result in ("tests.py", "test_host_bridge.py", "test_work_host.js",
               "COMPLETED_UNVERIFIED", "AWAITING_HOST_EXECUTION", "PLANNED_NOT_RUN",
               "WRITE_AUTHORIZATION_REQUIRED", "actions/upload-artifact@v4", "contents: read"):
    assert result in workflow
run = next(row for row in returned("commit-workflow-runs")["workflow_runs"] if row["name"] == "skill-router-v2-candidate")
job = next(row for row in returned("candidate-ci-jobs")["jobs"] if row["name"] == "local-execution-and-contract")
assert run["id"] == job["run_id"] == rows["candidate-ci-jobs"]["args"]["run_id"]
assert run["conclusion"] == job["conclusion"] == "success"
print(json.dumps({"run": run, "job": job}, ensure_ascii=False))
