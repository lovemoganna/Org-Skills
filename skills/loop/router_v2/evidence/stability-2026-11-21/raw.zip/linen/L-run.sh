#!/usr/bin/env bash
set -u
checkout=$1
here=$(cd -- "$(dirname -- "$0")" && pwd)
run=$(mktemp -d "$here/L-raw.XXXXXXXX")
(
  set -x
  python3 "$here/L-verify.py" "$checkout" "$here/L-connector-raw.json"
) > "$run/commands-and-results.log" 2>&1
status=$?
printf 'exit_code=%s\n' "$status" > "$run/exit.txt"
printf '%s\n' "$run"
exit "$status"
