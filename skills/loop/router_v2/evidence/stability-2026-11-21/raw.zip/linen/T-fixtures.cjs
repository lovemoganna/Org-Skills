const assert = require("node:assert/strict");
const { spawnSync } = require("node:child_process");
const { createHash } = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { runInThisContext } = require("node:vm");

const [checkout, evidence] = process.argv.slice(2);
const router = "skills/loop/router_v2";
const driverSource = path.join(checkout, router, "work_host.js");
const loadDriver = runInThisContext(fs.readFileSync(driverSource, "utf8") + "\nworkHost;");
const fixtureContent = "Local router receipt fixture\n";
const fixtureBytes = Buffer.from(fixtureContent, "utf8");
const fixtureSha = createHash("sha1").update(`blob ${fixtureBytes.length}\0`).update(fixtureBytes).digest("hex");
const connectorKey = "mcp__codex_apps__github_fetch_file";
const scenarios = [
  ["github-404", {
    content: [{ type: "text", text: "GitHub API error 404: Not Found (local fixture)" }],
    structuredContent: { error: "GitHub API error 404: Not Found (local fixture)",
      error_code: "NOT_FOUND", error_data: { status: "404" } },
    isError: true,
  }, "FAILED", "HALTED_ON_STEP_FAILURE", 1],
  ["empty-structured-content", {
    content: [{ type: "text", text: "Action completed. (local fixture)" }],
    structuredContent: {},
    isError: false,
  }, "FAILED", "HALTED_ON_STEP_FAILURE", 1],
  ["valid-sha-and-text", {
    content: [{ type: "text", text: "Action completed. (local fixture)" }],
    structuredContent: { sha: fixtureSha, content: fixtureContent, encoding: "utf-8" },
    isError: false,
  }, "RECEIPTS_RECORDED_UNVERIFIED", "ALL_STEPS_REPORTED", 0],
];

function log(entry) {
  console.log(JSON.stringify(entry));
}

async function main() {
  fs.mkdirSync(evidence);
  for (const [scenario, response, finalStatus, phase, recordExit] of scenarios) {
    const session = path.join(evidence, scenario);
    const plan = path.join(evidence, `${scenario}-plan.json`);
    const bridgeExits = [];
    const calls = [];
    const host = loadDriver({
      exec_command({ cmd, workdir }) {
        assert.equal(workdir, checkout);
        const processResult = spawnSync("bash", ["-c", cmd], {
          cwd: workdir, encoding: "utf8", env: { ...process.env, PYTHONDONTWRITEBYTECODE: "1" },
        });
        if (processResult.error) throw processResult.error;
        const { status, stdout, stderr } = processResult;
        log({ scenario, command: ["bash", "-c", cmd], cwd: workdir, exit_code: status, stdout, stderr });
        if (cmd.startsWith("python3 ")) bridgeExits.push(status);
        return { exit_code: status, output: stdout + stderr };
      },
      async [connectorKey](args) {
        calls.push(args);
        log({ scenario, connector: connectorKey, local_fixture: true, args, response });
        return response;
      },
    }, checkout);
    const args = { repository_full_name: "fixture-owner/fixture-repo",
      path: "README.md", ref: "0".repeat(40) };
    await host.save(plan, {
      id: scenario, goal: "Run the candidate Work driver's read receipt state transitions with local fixtures",
      steps: [{ id: "read", kind: "tool", target: "github.fetch_file", args }],
      acceptance: [{ id: "file_read", evidence_from: ["read"] }],
    });
    await host.init(session, plan);
    const state = await host.advance(session);
    const receipt = JSON.parse(fs.readFileSync(path.join(session, "read-1-receipt.json"), "utf8"));
    const report = JSON.parse(fs.readFileSync(path.join(session, "read-1-report.json"), "utf8"));
    fs.writeFileSync(path.join(session, "final-state.json"), JSON.stringify(state, null, 2) + "\n");
    log({ scenario, final_state: state, bridge_exit_codes: bridgeExits });
    assert.deepEqual(calls, [args]);
    assert.deepEqual(receipt.response, response);
    assert.deepEqual([state.status, state.phase], [finalStatus, phase]);
    assert.deepEqual(bridgeExits, [0, 0, recordExit]);
    assert.equal(state.pending_request, null);
    assert.equal(report.receipt_ref, "read-1-receipt.json");
    assert.deepEqual(
      [report.status, report.artifact_ref, state.completed_step_ids],
      recordExit ? ["FAILED", null, []] : ["SUCCESS", "read-1-receipt.json", ["read"]],
    );
    if (scenario === "github-404") assert.match(receipt.error, /404/);
    if (scenario === "empty-structured-content") assert.match(receipt.error, /incomplete data/);
    if (!recordExit) {
      assert.equal(receipt.error, undefined);
      assert.equal(state.acceptance.file_read.status, "HOST_REPORTED");
      assert.equal(state.evidence_trust, "HOST_REPORTED_NOT_INDEPENDENTLY_AUTHENTICATED");
    }
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
