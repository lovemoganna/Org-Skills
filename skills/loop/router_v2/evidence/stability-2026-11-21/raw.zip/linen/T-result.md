# Work 驱动如何记录 GitHub 文件读取

候选提交 `af94fbae23326e6ac9626bf525407fcaf59f7659`。每案开启独立会话，运行真实 `work_host.js` 和 `host_bridge.py`，只替换 GitHub 连接器响应。

| 本地替身响应 | 步骤记录 | 会话最终状态 | Bridge `record` 退出码 |
| --- | --- | --- | --- |
| GitHub 404（`isError: true`，`NOT_FOUND`） | `FAILED`，保留 404 原始回执，`artifact_ref: null` | `FAILED` / `HALTED_ON_STEP_FAILURE` | 1 |
| `structuredContent: {}`，外层自称成功 | `FAILED`，原始回执记下 `Connector returned incomplete data for github.fetch_file`，`artifact_ref: null` | `FAILED` / `HALTED_ON_STEP_FAILURE` | 1 |
| `structuredContent` 含字符串内容和合法的 40 位小写十六进制 SHA | `SUCCESS`，回执同时作为产物引用 | `RECEIPTS_RECORDED_UNVERIFIED` / `ALL_STEPS_REPORTED`，验收仅为 `HOST_REPORTED` | 0 |

第三案可确认本地实验中读取步骤已记录，三案的会话均没有独立完成凭证。驱动只校验响应字段类型和 SHA 格式。要声称任务完成，需另行核验源内容、目标和验收结果。两种失败各只请求一次，没有自动重试。实验只覆盖这三种 `github.fetch_file` 响应及其本地状态转换，GitHub 在线行为、无人值守运行和正式发布均超出此证据范围。

复现命令为 `bash ./T-run.sh /workspace/scratch/7b0baee69f08/stable-candidate`。实际执行总退出码为 0，表示三组断言通过。见 [命令与原始结果](T-raw.suDwW9au/commands-and-results.log)、[退出状态](T-raw.suDwW9au/exit.txt) 和三份 [404 回执](T-raw.suDwW9au/sessions/github-404/read-1-receipt.json)、[空响应回执](T-raw.suDwW9au/sessions/empty-structured-content/read-1-receipt.json)、[有效响应回执](T-raw.suDwW9au/sessions/valid-sha-and-text/read-1-receipt.json)。
