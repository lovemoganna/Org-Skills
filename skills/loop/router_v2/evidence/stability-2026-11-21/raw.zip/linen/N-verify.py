import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

checkout, out = map(Path, sys.argv[1:])
candidate = "af94fbae23326e6ac9626bf525407fcaf59f7659"
evidence = "skills/loop/router_v2/evidence/work-2026-11-21/C-replay"
source = checkout / evidence


def command(*argv, stdin=None, expected=0):
    completed = subprocess.run(argv, cwd=checkout, input=stdin, capture_output=True,
                               env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
    print(json.dumps({"argv": argv, "cwd": str(checkout), "status": completed.returncode,
                      "stdout": completed.stdout.decode(), "stderr": completed.stderr.decode()},
                     ensure_ascii=False))
    assert completed.returncode == expected
    return completed.stdout


assert command("git", "rev-parse", "HEAD").decode().strip() == candidate
for name in ("read-1-receipt.json", "read-2-receipt.json", "trace.jsonl",
             "read-1-report.json", "read-2-report.json", "session.json"):
    pointer = candidate + ":" + evidence + "/" + name
    source_file = source / name
    raw = source_file.read_bytes()
    (out / name).write_bytes(raw)
    assert command("git", "rev-parse", pointer).strip() == command("git", "hash-object", "--", str(source_file)).strip()
    print(json.dumps({"source": str(source_file), "pinned_object": pointer, "sha256": hashlib.sha256(raw).hexdigest()}))

failed = json.loads((out / "read-1-receipt.json").read_bytes())
recovered = json.loads((out / "read-2-receipt.json").read_bytes())
first_report = json.loads((out / "read-1-report.json").read_bytes())
second_report = json.loads((out / "read-2-report.json").read_bytes())
init, first, retry, second = (json.loads(line) for line in (out / "trace.jsonl").read_bytes().splitlines())
assert [e["event"] for e in (init, first, retry, second)] == [
    "INIT", "HOST_RESULT_RECORDED", "READ_RETRY_REQUESTED", "HOST_RESULT_RECORDED"]
assert sorted(e["at"] for e in (init, first, retry, second)) == [e["at"] for e in (init, first, retry, second)]
assert failed["response"]["isError"] is True
assert failed["response"]["structuredContent"]["error_data"]["status"] == "404"
assert recovered["response"]["isError"] is False
assert first["status"] == first_report["status"] == "FAILED"
assert second["status"] == second_report["status"] == "SUCCESS"
assert first["attempt"] == 1 and recovered["request"]["attempt"] == second["attempt"] == 2
assert first["artifact_ref"] == first_report["artifact_ref"] is None
assert second["artifact_ref"] == second_report["artifact_ref"] == "read-2-receipt.json"
assert failed["request"]["request_sha256"] == first["request_sha256"] == first_report["request_sha256"] == retry["failed_request_sha256"]
assert recovered["request"]["request_sha256"] == second["request_sha256"] == second_report["request_sha256"]
assert first["request_sha256"] != second["request_sha256"]
assert failed["error"] == first["error"] == first_report["error"]
assert second["error"] == second_report["error"] is None
assert failed["tool"] == recovered["tool"] == "mcp__codex_apps__github_fetch_file"
assert failed["request"]["side_effect_class"] == recovered["request"]["side_effect_class"] == "read"
before = failed["request"]["args"]
after = recovered["request"]["args"]
assert set(before) == set(after) == {"repository_full_name", "ref", "path"}
assert before["repository_full_name"] == after["repository_full_name"] == "lovemoganna/Org-Skills"
assert before["ref"] == after["ref"] == "06c23284dd275cf424eeecce6fd0b6faaee298e6"
assert (before["path"], retry["path"], after["path"]) == (
    "skills/loop/router_v2/README.missing.md", "skills/loop/router_v2/README.md", "skills/loop/router_v2/README.md")

data = recovered["response"]["structuredContent"]
assert data["encoding"] == "utf-8"
raw = data["content"].encode("utf-8")
(out / "recovered-content.bin").write_bytes(raw)
header = f"blob {len(raw)}".encode("ascii") + bytes([0])
declared = data["sha"]
computed = hashlib.sha1(header + raw).hexdigest()
git_stdin = command("git", "hash-object", "--stdin", stdin=raw).decode().strip()
git_pinned = command("git", "rev-parse", f"{after['ref']}:{after['path']}").decode().strip()
assert declared == computed == git_stdin == git_pinned
assert command("git", "cat-file", "blob", git_pinned) == raw
command("git", "cat-file", "-e", f"{before['ref']}:{before['path']}", expected=128)
state = json.loads(command("python3", "skills/loop/router_v2/host_bridge.py", "next", "--session", str(source)))
assert state["status"] == "RECEIPTS_RECORDED_UNVERIFIED"
print(json.dumps({"first": before, "second": after, "retry_reason": retry["reason"],
                  "bytes": len(raw), "blob_header_hex": header.hex(), "declared_sha": declared,
                  "recomputed_sha": computed, "git_stdin_sha": git_stdin, "pinned_object_sha": git_pinned,
                  "pinned_bytes_match": True, "bridge_state": state["status"]},
                 ensure_ascii=False, indent=2))
