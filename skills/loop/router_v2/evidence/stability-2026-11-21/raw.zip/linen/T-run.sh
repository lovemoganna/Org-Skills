#!/usr/bin/env bash
set -u
checkout=$1
here=$(cd -- "$(dirname -- "$0")" && pwd)
run=$(mktemp -d "$here/T-raw.XXXXXXXX")
(
  set -x
  git -C "$checkout" rev-parse HEAD
  git -C "$checkout" status --porcelain=v1
  git -C "$checkout" diff --exit-code HEAD -- skills/loop/router_v2/work_host.js skills/loop/router_v2/host_bridge.py
  node --version
  python3 --version
  PYTHONDONTWRITEBYTECODE=1 node "$here/T-fixtures.cjs" "$checkout" "$run/sessions"
  result=$?
  git -C "$checkout" status --porcelain=v1
  printf 'fixture_harness_exit=%s\n' "$result"
  exit "$result"
) > "$run/commands-and-results.log" 2>&1
exit_code=$?
printf 'exit_code=%s\n' "$exit_code" > "$run/exit.txt"
printf '%s\n' "$run"
exit "$exit_code"
