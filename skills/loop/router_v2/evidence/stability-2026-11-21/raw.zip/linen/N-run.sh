#!/usr/bin/env bash
set -u
checkout=$1
here=$(cd -- "$(dirname -- "$0")" && pwd)
run=$(mktemp -d "$here/N-raw.XXXXXXXX")
(
  set -x
  python3 "$here/N-verify.py" "$checkout" "$run"
) > "$run/commands-and-results.log" 2>&1
status=$?
printf 'exit_code=%s\n' "$status" > "$run/exit.txt"
printf '%s\n' "$run"
exit "$status"
