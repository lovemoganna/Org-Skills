# PR #118 发布审查

**暂缓发布，保留 PR #118 的 Draft 状态。** 固定提交 `af94fbae23326e6ac9626bf525407fcaf59f7659` 的 CI 通过了本地文件执行和协议检查。无人值守模型路由与正式部署仍缺端到端证据。

| GitHub 实际读取 | 证据 |
|---|---|
| PR #118 当前元数据 | `state: open`、`draft: true`、`merged: false`，`head_sha` 等于固定提交。 |
| 固定提交的 `.github/workflows/skill-router-v2-candidate.yml` | 运行本地文件测试、host bridge 协议和 JS 驱动契约测试。两项沙箱任务要求达到 `COMPLETED_UNVERIFIED` 加 `PASS_LOCAL_RECHECK`，未授权写入须为 `BLOCKED`。Host 协议在 `AWAITING_HOST_EXECUTION` / `PLANNED_NOT_RUN` 停止。Blob SHA `8d9993bf287e0159cb743318710258fbc701792a`。 |
| 候选提交的 Actions 运行、任务与制品元数据 | Run `44876927347` 和 job `136763562235` 均为 `success`。执行步骤是本地测试、两项沙箱任务与上传本地回执。制品 `14696640128` 的元数据把该 run 关联到固定提交。 |
| 固定提交的 Work `C-replay/trace.jsonl` | 记录先失败、显式请求纠正、再读取成功。Blob SHA `e19794460357768f82acfdeb2cbcea7c8e2b236b`。该记录覆盖主动 Work 会话中的一次读取恢复。 |

用 GitHub 返回的 UTF-8 原文执行 `git hash-object --stdin`，两份文件均匹配回执 SHA 和固定提交的 Git 对象，原文逐字节一致。实际工具名、参数、原始返回保存在 `L-raw/`。本地校验见 `L-verify.py` 和 `L-execution.log`，退出码为 0。

重新审查需提供两组同版本证据。第一组是无需活动 Work 会话或人工代调度的原生执行器运行记录，覆盖自动选择、真实调用、失败处理、权限边界及独立任务验收。第二组是授权目标环境的部署记录，带实际版本、健康检查、独立服务验收和可验证的回滚演练结果。
