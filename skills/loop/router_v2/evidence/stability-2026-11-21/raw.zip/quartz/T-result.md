# Work 驱动读取回执实测

固定提交 `af94fbae23326e6ac9626bf525407fcaf59f7659`。三次独立会话均运行候选的 `work_host.js` 和 `host_bridge.py`。GitHub 响应由本地测试替身提供，每次只分派一次读取。

| 替身返回 | 步骤记录 | 会话最终状态 | bridge `record` 退出码 |
|---|---|---|---|
| GitHub 404，`isError: true`、`error_code: NOT_FOUND` | `FAILED`，保留 404 原始回执，`artifact_ref: null` | `FAILED` / `HALTED_ON_STEP_FAILURE` | 1 |
| `structuredContent: {}`，外层提示 `Action completed.` | `FAILED`，回执注明 `Connector returned incomplete data for github.fetch_file`，`artifact_ref: null` | `FAILED` / `HALTED_ON_STEP_FAILURE` | 1 |
| 文本与合法的 40 位小写 Git Blob SHA | `SUCCESS`，`receipt_ref` 和 `artifact_ref` 均指向同一份回执 | `RECEIPTS_RECORDED_UNVERIFIED` / `ALL_STEPS_REPORTED`，验收为 `HOST_REPORTED` | 0 |

第三种可以报告“读取步骤成功，回执已记录”。明示“已独立验证完成”还需要在固定来源复核内容和 SHA，并独立核对实际任务验收条件。驱动只检查字符串类型与 SHA 格式，bridge 校验报告协议，两者均未验证 GitHub 来源真实性。此轮只覆盖 `github.fetch_file` 的三种本地替身响应。

运行器 `T-driver.cjs` 总退出码为 0，表示三种结果符合断言。`T-execution.json` 保存运行命令和退出状态，`T-raw/calls.jsonl` 保存实际 bridge 命令及输出。`T-raw/` 各场景子目录保存原始回执、报告和 trace，同层含最终状态。
