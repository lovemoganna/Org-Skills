const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const { createHash } = require('node:crypto');
const { appendFileSync, mkdirSync, readFileSync, writeFileSync } = require('node:fs');
const { join, resolve } = require('node:path');
const { runInThisContext } = require('node:vm');

const [checkout, output] = process.argv.slice(2).map((path) => resolve(path));
const candidate = 'af94fbae23326e6ac9626bf525407fcaf59f7659';
const head = spawnSync('git', ['rev-parse', 'HEAD'], { cwd: checkout, encoding: 'utf8' });
assert.equal(head.status, 0);
assert.equal(head.stdout.trim(), candidate);
mkdirSync(output);

const hostSource = join(checkout, 'skills/loop/router_v2/work_host.js');
const driver = runInThisContext(readFileSync(hostSource, 'utf8') + '\nworkHost;', { filename: hostSource });
const log = (entry) => appendFileSync(join(output, 'calls.jsonl'), JSON.stringify(entry) + '\n');
const save = (name, value) => writeFileSync(join(output, name), JSON.stringify(value, null, 2) + '\n');
const fixtureText = 'README fixture with UTF-8 文本\n';
const fixtureBytes = Buffer.from(fixtureText);
const fixtureSha = createHash('sha1').update('blob ' + fixtureBytes.length + '\0').update(fixtureBytes).digest('hex');
const scenarios = [
  {
    id: 'github-404',
    response: { content: [{ type: 'text', text: 'GitHub API error 404: Not Found' }], structuredContent: { error: 'GitHub API error 404: Not Found', error_code: 'NOT_FOUND', error_data: { status: '404' } }, isError: true },
    error: 'GitHub API error 404: Not Found',
  },
  {
    id: 'empty-structured',
    response: { content: [{ type: 'text', text: 'Action completed.' }], structuredContent: {}, isError: false },
    error: 'Connector returned incomplete data for github.fetch_file',
  },
  {
    id: 'valid-structured',
    response: { content: [{ type: 'text', text: 'Action completed.' }], structuredContent: { content: fixtureText, sha: fixtureSha, encoding: 'utf-8' }, isError: false },
    error: null,
  },
];

async function main() {
  console.log(JSON.stringify({ driver: hostSource, candidate, external_github: 'LOCAL TEST DOUBLE', fixtureSha }));
  for (const scenario of scenarios) {
    const session = join(output, scenario.id);
    const plan = join(output, scenario.id + '-plan.json');
    const failing = scenario.error !== null;
    const expectedExit = failing ? 1 : 0;
    const step = {
      id: 'read',
      kind: 'tool',
      target: 'github.fetch_file',
      args: { repository_full_name: 'fixture/repo', path: 'README.md', ref: candidate },
    };
    let dispatches = 0;
    const host = driver({
      exec_command: ({ cmd, workdir }) => {
        const result = spawnSync('bash', ['-c', cmd], {
          cwd: workdir, encoding: 'utf8', env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' },
        });
        if (result.error) throw result.error;
        log({ scenario: scenario.id, cmd, cwd: workdir, exit: result.status, stdout: result.stdout, stderr: result.stderr });
        if (cmd.includes("'record'")) assert.equal(result.status, expectedExit);
        return { exit_code: result.status, output: result.stdout + result.stderr };
      },
      mcp__codex_apps__github_fetch_file: async (args) => {
        assert.deepEqual(args, step.args);
        dispatches += 1;
        log({ scenario: scenario.id, source: 'LOCAL GITHUB TEST DOUBLE', args, response: scenario.response });
        return structuredClone(scenario.response);
      },
    }, checkout);
    await host.save(plan, {
      id: scenario.id, goal: 'Test recorded GitHub file response handling', steps: [step],
      acceptance: [{ id: 'read-evidence', criteria: 'Return file content and blob SHA', evidence_from: ['read'] }],
    });
    const initial = await host.init(session, plan);
    assert.equal(initial.status, 'PLANNED_NOT_RUN');
    const final = await host.advance(session);
    save(scenario.id + '-final.json', final);
    const receipt = JSON.parse(readFileSync(join(session, 'read-1-receipt.json'), 'utf8'));
    const report = JSON.parse(readFileSync(join(session, 'read-1-report.json'), 'utf8'));
    assert.equal(dispatches, 1);
    assert.equal(final.phase, failing ? 'HALTED_ON_STEP_FAILURE' : 'ALL_STEPS_REPORTED');
    assert.equal(final.status, failing ? 'FAILED' : 'RECEIPTS_RECORDED_UNVERIFIED');
    assert.deepEqual(final.completed_step_ids, failing ? [] : ['read']);
    assert.equal(final.pending_request, null);
    assert.equal(final.evidence_trust, 'HOST_REPORTED_NOT_INDEPENDENTLY_AUTHENTICATED');
    assert.equal(final.independence, 'self-check only');
    if (!failing) assert.equal(final.acceptance['read-evidence'].status, 'HOST_REPORTED');
    assert.equal(receipt.error, scenario.error ?? undefined);
    assert.equal(report.error, scenario.error);
    assert.equal(report.status, failing ? 'FAILED' : 'SUCCESS');
    assert.equal(report.artifact_ref, failing ? null : 'read-1-receipt.json');
    console.log(JSON.stringify({ case: scenario.id, bridge_record_exit: expectedExit, dispatches, report, final }));
  }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
