import hashlib
import json
import pathlib
import subprocess
import sys

checkout = pathlib.Path(sys.argv[1]).resolve()
raw = pathlib.Path(sys.argv[2]).resolve()
ref = 'af94fbae23326e6ac9626bf525407fcaf59f7659'
repo = 'lovemoganna/Org-Skills'


def data(name):
    item = json.loads((raw / f'{name}.json').read_bytes())
    assert item['response']['isError'] is False
    return item['args'], item['response']['structuredContent']


def git(*args, body=None):
    result = subprocess.run(['git', *args], cwd=checkout, input=body, capture_output=True)
    print(json.dumps({'command': ['git', *args], 'cwd': str(checkout), 'exit': result.returncode,
                      'stdin_bytes': len(body) if body is not None else None,
                      'stdout_bytes': len(result.stdout),
                      'stdout': result.stdout.decode() if args[0] != 'show' else None,
                      'stderr': result.stderr.decode()}))
    result.check_returncode()
    return result.stdout


assert git('rev-parse', 'HEAD').decode().strip() == ref
verified_files = {}
for name, source in {
    'workflow': '.github/workflows/skill-router-v2-candidate.yml',
    'work-trace': 'skills/loop/router_v2/evidence/work-2026-11-21/C-replay/trace.jsonl',
}.items():
    params, receipt = data(name)
    assert params == {'repository_full_name': repo, 'path': source, 'ref': ref}
    assert receipt['encoding'] == 'utf-8'
    returned = receipt['content'].encode('utf-8')
    checked_out = git('show', f'{ref}:{source}')
    commit_sha = git('rev-parse', f'{ref}:{source}').decode().strip()
    blob_sha = git('hash-object', '--stdin', body=returned).decode().strip()
    python_sha = hashlib.sha1(f'blob {len(returned)}\0'.encode() + returned).hexdigest()
    assert returned == checked_out
    assert receipt['sha'] == blob_sha == python_sha == commit_sha
    print(json.dumps({'checked': source, 'bytes': len(returned), 'remote_sha': receipt['sha'],
                      'git_hash_object': blob_sha, 'checkout_object': commit_sha, 'bytes_equal': True}))
    verified_files[name] = receipt['content']

pr_args, pr = data('pr-118')
assert pr_args == {'repository_full_name': repo, 'pr_number': 118}
assert pr['number'] == 118 and pr['head_sha'] == ref
assert pr['draft'] and not pr['merged'] and pr['state'] == 'open'
run_args, runs = data('workflow-runs')
assert run_args == {'repo_full_name': repo, 'commit_sha': ref}
runs = runs['workflow_runs']
build = next(run for run in runs if run['name'] == 'skill-router-v2-candidate')
assert build['status'] == 'completed' and build['conclusion'] == 'success'
jobs_args, jobs = data('workflow-jobs')
assert jobs_args == {'repo_full_name': repo, 'run_id': build['id']}
job, = jobs['jobs']
assert job['name'] == 'local-execution-and-contract' and job['conclusion'] == 'success'
artifact_args, artifacts = data('workflow-artifacts')
assert artifact_args == jobs_args
artifact, = artifacts['artifacts']
assert artifact['name'] == 'skill-router-v2-local-receipts'
assert artifact['workflow_run']['head_sha'] == ref and artifact['workflow_run']['id'] == build['id']
workflow = verified_files['workflow']
for mark in ('contents: read', 'test_work_host.js', 'demo_write.json', 'demo_replace.json',
             '"COMPLETED_UNVERIFIED"', '"PASS_LOCAL_RECHECK"', '"WRITE_AUTHORIZATION_REQUIRED"',
             '"AWAITING_HOST_EXECUTION"', '"PLANNED_NOT_RUN"', 'actions/upload-artifact@v4'):
    assert mark in workflow, mark
trace = [json.loads(line) for line in verified_files['work-trace'].splitlines()]
assert [e['event'] for e in trace] == ['INIT', 'HOST_RESULT_RECORDED', 'READ_RETRY_REQUESTED', 'HOST_RESULT_RECORDED']
assert [(e['attempt'], e['status']) for e in trace if e['event'] == 'HOST_RESULT_RECORDED'] == [(1, 'FAILED'), (2, 'SUCCESS')]
print(json.dumps({'pr': {k: pr[k] for k in ('number', 'state', 'draft', 'merged', 'head_sha')},
                  'workflow_runs': runs, 'jobs': jobs['jobs'], 'artifact': artifact,
                  'work_event_order': [e['event'] for e in trace], 'checks': 'PASS'}))
