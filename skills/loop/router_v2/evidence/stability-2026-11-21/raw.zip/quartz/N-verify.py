import hashlib
import json
import pathlib
import subprocess
import sys

checkout = pathlib.Path(sys.argv[1]).resolve()
out = pathlib.Path(sys.argv[2]).resolve()
out.mkdir(exist_ok=True)
source = pathlib.Path('skills/loop/router_v2/evidence/work-2026-11-21/C-replay')
candidate = 'af94fbae23326e6ac9626bf525407fcaf59f7659'


def preserve(name, data):
    path = out / name
    if path.exists():
        assert path.read_bytes() == data, name
    else:
        path.write_bytes(data)


def git(*args, data=None):
    run = subprocess.run(['git', *args], cwd=checkout, input=data, capture_output=True)
    print(json.dumps({'command': ['git', *args], 'cwd': str(checkout), 'exit': run.returncode,
                      'stdin_bytes': len(data) if data is not None else None,
                      'stdout_bytes': len(run.stdout),
                      'stdout': run.stdout.decode() if args[0] != 'show' else None,
                      'stderr': run.stderr.decode()}, ensure_ascii=False))
    run.check_returncode()
    return run.stdout


assert git('rev-parse', 'HEAD').decode().strip() == candidate
names = ('read-1-receipt.json', 'read-2-receipt.json', 'trace.jsonl',
         'read-1-report.json', 'read-2-report.json', 'session.json')
for name in names:
    data = git('show', f'{candidate}:{source / name}')
    preserve(name, data)
    print(json.dumps({'source': str(source / name), 'raw_copy': str(out / name),
                      'sha256': hashlib.sha256(data).hexdigest()}))


def load(name):
    return json.loads((out / name).read_bytes())


task_path = source.parent / 'C-replay-taskspec.json'
task_bytes = git('show', f'{candidate}:{task_path}')
preserve(task_path.name, task_bytes)
taskspec = json.loads(task_bytes)
failed = load('read-1-receipt.json')
recovery = load('read-2-receipt.json')
failed_report = load('read-1-report.json')
recover_report = load('read-2-report.json')
session = load('session.json')
trace = [json.loads(line) for line in (out / 'trace.jsonl').read_bytes().splitlines()]
initial, failure_event, retry_event, recovery_event = trace

assert taskspec == session['plan']
assert initial['event'] == 'INIT'
assert failure_event['event'] == recovery_event['event'] == 'HOST_RESULT_RECORDED'
assert retry_event['event'] == 'READ_RETRY_REQUESTED'
assert failed['response']['isError'] is True
assert failed['response']['structuredContent']['error_data']['status'] == '404'
assert failed['response']['structuredContent']['error_code'] == 'NOT_FOUND'
assert failed_report['status'] == failure_event['status'] == 'FAILED'
assert failed_report['artifact_ref'] is failure_event['artifact_ref'] is None
assert failed_report['receipt_ref'] == failure_event['receipt_ref'] == 'read-1-receipt.json'
assert failed_report['request_sha256'] == failure_event['request_sha256'] == retry_event['failed_request_sha256'] == failed['request']['request_sha256']
assert recovery['response']['isError'] is False
assert recover_report['status'] == recovery_event['status'] == 'SUCCESS'
assert recover_report['artifact_ref'] == recovery_event['artifact_ref'] == 'read-2-receipt.json'
assert recover_report['request_sha256'] == recovery_event['request_sha256'] == recovery['request']['request_sha256']
assert failure_event['attempt'] == 1 and recovery_event['attempt'] == recovery['request']['attempt'] == 2
first_args, last_args = failed['request']['args'], recovery['request']['args']
assert taskspec['steps'][0]['args'] == first_args
assert {key for key in first_args if first_args[key] != last_args[key]} == {'path'}
assert first_args.keys() == last_args.keys()
assert first_args['path'] == 'skills/loop/router_v2/README.missing.md'
assert last_args['path'] == retry_event['path'] == 'skills/loop/router_v2/README.md'
assert session['read_retries']['read']['failed_attempt']['request_sha256'] == failed['request']['request_sha256']
assert session['host_write_authorization_declared'] is False
assert failed['request']['side_effect_class'] == recovery['request']['side_effect_class'] == 'read'

response = recovery['response']['structuredContent']
assert response['encoding'] == 'utf-8'
body = response['content'].encode('utf-8')
preserve('recovered-content.utf8', body)
header = f'blob {len(body)}\0'.encode('ascii')
calculated = hashlib.sha1(header + body).hexdigest()
git_calculated = git('hash-object', '--stdin', data=body).decode().strip()
ref = last_args['ref']
path = last_args['path']
git_blob = git('rev-parse', f'{ref}:{path}').decode().strip()
original = git('show', f'{ref}:{path}')
assert calculated == git_calculated == response['sha'] == git_blob
assert body == original

print(json.dumps({'failed_request': first_args, 'recovery_request': last_args,
                  'failed_event': failure_event, 'retry_event': retry_event, 'recovery_event': recovery_event,
                  'body_bytes': len(body), 'header_hex': header.hex(),
                  'computed_git_blob_sha': calculated, 'receipt_sha': response['sha'],
                  'pinned_git_blob_sha': git_blob, 'byte_identical_to_pinned_blob': body == original,
                  'checks': 'PASS'}, ensure_ascii=False))
